<?php

namespace App;

trait HasLocation {

	protected function assingLocation() {

	}

	protected function getLocation() {

	}

}